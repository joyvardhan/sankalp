import { Tabs } from 'expo-router';
import { Chrome as Home, Briefcase, Code as Code2, Brain, Glasses, Notebook as Robot } from 'lucide-react-native';
import { useTheme } from '@/context/ThemeContext';

export default function TabLayout() {
  const { colors } = useTheme();

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          backgroundColor: colors.background,
          borderTopColor: colors.border,
        },
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.text,
      }}>
      <Tabs.Screen
        name="index"
        options={{
          title: 'Home',
          tabBarIcon: ({ color, size }) => <Home size={size} color={color} />,
        }}
      />
      <Tabs.Screen
        name="careers"
        options={{
          title: 'Careers',
          tabBarIcon: ({ color, size }) => <Briefcase size={size} color={color} />,
        }}
      />
      <Tabs.Screen
        name="fullstack"
        options={{
          title: 'Full Stack',
          tabBarIcon: ({ color, size }) => <Code2 size={size} color={color} />,
        }}
      />
      <Tabs.Screen
        name="competitive"
        options={{
          title: 'DSA',
          tabBarIcon: ({ color, size }) => <Brain size={size} color={color} />,
        }}
      />
      <Tabs.Screen
        name="arvr"
        options={{
          title: 'AR/VR',
          tabBarIcon: ({ color, size }) => <Glasses size={size} color={color} />,
        }}
      />
      <Tabs.Screen
        name="ai"
        options={{
          title: 'AI',
          tabBarIcon: ({ color, size }) => <Robot size={size} color={color} />,
        }}
      />
    </Tabs>
  );
}