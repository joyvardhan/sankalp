import { StyleSheet, View, ScrollView, Text, Image, Pressable } from 'react-native';
import Animated, { 
  FadeInDown,
  useAnimatedStyle,
  withSpring,
  useSharedValue
} from 'react-native-reanimated';
import { Brain, Bot, ChartBar, Network } from 'lucide-react-native';

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

const aiTracks = [
  {
    icon: <Brain size={24} color="#8B5CF6" />,
    title: "Machine Learning",
    topics: ["Neural Networks", "Deep Learning", "Computer Vision", "NLP"]
  },
  {
    icon: <Bot size={24} color="#8B5CF6" />,
    title: "AI Applications",
    topics: ["Chatbots", "Recommendation Systems", "Image Recognition", "Voice AI"]
  },
  {
    icon: <ChartBar size={24} color="#8B5CF6" />,
    title: "Data Science",
    topics: ["Data Analysis", "Visualization", "Statistics", "Big Data"]
  },
  {
    icon: <Network size={24} color="#8B5CF6" />,
    title: "MLOps",
    topics: ["Model Deployment", "Monitoring", "Pipeline Automation", "Version Control"]
  }
];

const projects = [
  {
    title: "AI-Powered Healthcare",
    description: "Disease prediction and medical imaging analysis",
    image: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&w=600&q=80",
    duration: "16 weeks"
  },
  {
    title: "Smart Assistant",
    description: "Natural language processing and conversation AI",
    image: "https://images.unsplash.com/photo-1589254065878-42c9da997008?auto=format&fit=crop&w=600&q=80",
    duration: "12 weeks"
  },
  {
    title: "Computer Vision App",
    description: "Real-time object detection and recognition",
    image: "https://images.unsplash.com/photo-1507146426996-ef05306b995a?auto=format&fit=crop&w=600&q=80",
    duration: "14 weeks"
  }
];

export default function AIScreen() {
  const scale = useSharedValue(1);

  const cardStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const onPressIn = () => {
    scale.value = withSpring(0.98);
  };

  const onPressOut = () => {
    scale.value = withSpring(1);
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Image
          source={{ uri: "https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&w=1200&q=80" }}
          style={styles.headerImage}
        />
        <View style={styles.overlay} />
        <View style={styles.headerContent}>
          <Animated.Text 
            entering={FadeInDown.duration(1000)}
            style={styles.title}
          >
            Artificial Intelligence
          </Animated.Text>
          <Animated.Text 
            entering={FadeInDown.duration(1000).delay(200)}
            style={styles.subtitle}
          >
            Master AI and transform the future of technology
          </Animated.Text>
        </View>
      </View>

      <View style={styles.tracksSection}>
        <Animated.Text 
          entering={FadeInDown.duration(1000).delay(400)}
          style={styles.sectionTitle}
        >
          Learning Tracks
        </Animated.Text>

        <View style={styles.trackGrid}>
          {aiTracks.map((track, index) => (
            <Animated.View
              key={track.title}
              entering={FadeInDown.duration(1000).delay(600 + index * 200)}
              style={styles.trackCard}
            >
              {track.icon}
              <Text style={styles.trackTitle}>{track.title}</Text>
              <View style={styles.topicsContainer}>
                {track.topics.map((topic) => (
                  <View key={topic} style={styles.topicBadge}>
                    <Text style={styles.topicText}>{topic}</Text>
                  </View>
                ))}
              </View>
            </Animated.View>
          ))}
        </View>
      </View>

      <View style={styles.projectsSection}>
        <Animated.Text 
          entering={FadeInDown.duration(1000).delay(1400)}
          style={styles.sectionTitle}
        >
          Industry Projects
        </Animated.Text>

        {projects.map((project, index) => (
          <AnimatedPressable
            key={project.title}
            entering={FadeInDown.duration(1000).delay(1600 + index * 200)}
            style={[styles.projectCard, cardStyle]}
            onPressIn={onPressIn}
            onPressOut={onPressOut}
          >
            <Image source={{ uri: project.image }} style={styles.projectImage} />
            <View style={styles.projectContent}>
              <Text style={styles.projectTitle}>{project.title}</Text>
              <Text style={styles.projectDescription}>{project.description}</Text>
              <View style={styles.projectDuration}>
                <Text style={styles.durationText}>{project.duration}</Text>
              </View>
            </View>
          </AnimatedPressable>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1a1a2e',
  },
  header: {
    height: 400,
    position: 'relative',
  },
  headerImage: {
    width: '100%',
    height: '100%',
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(26, 26, 46, 0.8)',
  },
  headerContent: {
    position: 'absolute',
    bottom: 40,
    left: 20,
    right: 20,
  },
  title: {
    fontSize: 36,
    fontWeight: 'bold',
    color: '#E5E7EB',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: '#9CA3AF',
    lineHeight: 24,
  },
  tracksSection: {
    padding: 20,
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#E5E7EB',
    marginBottom: 20,
  },
  trackGrid: {
    gap: 20,
  },
  trackCard: {
    backgroundColor: '#16213e',
    padding: 20,
    borderRadius: 12,
    marginBottom: 20,
  },
  trackTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#E5E7EB',
    marginTop: 12,
    marginBottom: 16,
  },
  topicsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  topicBadge: {
    backgroundColor: 'rgba(139, 92, 246, 0.1)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(139, 92, 246, 0.2)',
  },
  topicText: {
    color: '#8B5CF6',
    fontSize: 14,
    fontWeight: '500',
  },
  projectsSection: {
    padding: 20,
  },
  projectCard: {
    backgroundColor: '#16213e',
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 20,
  },
  projectImage: {
    width: '100%',
    height: 200,
  },
  projectContent: {
    padding: 16,
  },
  projectTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#E5E7EB',
    marginBottom: 8,
  },
  projectDescription: {
    fontSize: 14,
    color: '#9CA3AF',
    lineHeight: 20,
    marginBottom: 16,
  },
  projectDuration: {
    backgroundColor: 'rgba(139, 92, 246, 0.1)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    alignSelf: 'flex-start',
  },
  durationText: {
    color: '#8B5CF6',
    fontSize: 14,
    fontWeight: '500',
  },
});