import { StyleSheet, View, ScrollView, Text, Image, Pressable } from 'react-native';
import Animated, { 
  FadeInDown,
  useAnimatedStyle,
  withSpring,
  useSharedValue
} from 'react-native-reanimated';
import { Code2, Database, Globe, Layers } from 'lucide-react-native';

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

const technologies = [
  {
    icon: <Globe size={24} color="#8B5CF6" />,
    title: "Frontend Development",
    skills: ["React", "Next.js", "TypeScript", "Tailwind CSS"]
  },
  {
    icon: <Database size={24} color="#8B5CF6" />,
    title: "Backend Development",
    skills: ["Node.js", "Express", "PostgreSQL", "MongoDB"]
  },
  {
    icon: <Layers size={24} color="#8B5CF6" />,
    title: "DevOps & Cloud",
    skills: ["Docker", "AWS", "CI/CD", "Kubernetes"]
  },
  {
    icon: <Code2 size={24} color="#8B5CF6" />,
    title: "Tools & Best Practices",
    skills: ["Git", "Testing", "Security", "Performance"]
  }
];

const projects = [
  {
    title: "E-Commerce Platform",
    description: "Build a full-featured online store with payment integration",
    image: "https://images.unsplash.com/photo-1563013544-824ae1b704d3?auto=format&fit=crop&w=600&q=80",
    duration: "8 weeks"
  },
  {
    title: "Social Media App",
    description: "Create a real-time social platform with chat features",
    image: "https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?auto=format&fit=crop&w=600&q=80",
    duration: "6 weeks"
  },
  {
    title: "Project Management Tool",
    description: "Develop a collaborative project tracking system",
    image: "https://images.unsplash.com/photo-1507925921958-8a62f3d1a50d?auto=format&fit=crop&w=600&q=80",
    duration: "10 weeks"
  }
];

export default function FullStackScreen() {
  const scale = useSharedValue(1);

  const cardStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const onPressIn = () => {
    scale.value = withSpring(0.98);
  };

  const onPressOut = () => {
    scale.value = withSpring(1);
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Image
          source={{ uri: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=1200&q=80" }}
          style={styles.headerImage}
        />
        <View style={styles.overlay} />
        <View style={styles.headerContent}>
          <Animated.Text 
            entering={FadeInDown.duration(1000)}
            style={styles.title}
          >
            Full Stack Development
          </Animated.Text>
          <Animated.Text 
            entering={FadeInDown.duration(1000).delay(200)}
            style={styles.subtitle}
          >
            Master modern web development from frontend to backend
          </Animated.Text>
        </View>
      </View>

      <View style={styles.technologiesSection}>
        <Animated.Text 
          entering={FadeInDown.duration(1000).delay(400)}
          style={styles.sectionTitle}
        >
          What You'll Learn
        </Animated.Text>

        <View style={styles.techGrid}>
          {technologies.map((tech, index) => (
            <Animated.View
              key={tech.title}
              entering={FadeInDown.duration(1000).delay(600 + index * 200)}
              style={styles.techCard}
            >
              {tech.icon}
              <Text style={styles.techTitle}>{tech.title}</Text>
              <View style={styles.skillsContainer}>
                {tech.skills.map((skill) => (
                  <View key={skill} style={styles.skillBadge}>
                    <Text style={styles.skillText}>{skill}</Text>
                  </View>
                ))}
              </View>
            </Animated.View>
          ))}
        </View>
      </View>

      <View style={styles.projectsSection}>
        <Animated.Text 
          entering={FadeInDown.duration(1000).delay(1400)}
          style={styles.sectionTitle}
        >
          Real-World Projects
        </Animated.Text>

        {projects.map((project, index) => (
          <AnimatedPressable
            key={project.title}
            entering={FadeInDown.duration(1000).delay(1600 + index * 200)}
            style={[styles.projectCard, cardStyle]}
            onPressIn={onPressIn}
            onPressOut={onPressOut}
          >
            <Image source={{ uri: project.image }} style={styles.projectImage} />
            <View style={styles.projectContent}>
              <Text style={styles.projectTitle}>{project.title}</Text>
              <Text style={styles.projectDescription}>{project.description}</Text>
              <View style={styles.projectDuration}>
                <Text style={styles.durationText}>{project.duration}</Text>
              </View>
            </View>
          </AnimatedPressable>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1a1a2e',
  },
  header: {
    height: 400,
    position: 'relative',
  },
  headerImage: {
    width: '100%',
    height: '100%',
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(26, 26, 46, 0.8)',
  },
  headerContent: {
    position: 'absolute',
    bottom: 40,
    left: 20,
    right: 20,
  },
  title: {
    fontSize: 36,
    fontWeight: 'bold',
    color: '#E5E7EB',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: '#9CA3AF',
    lineHeight: 24,
  },
  technologiesSection: {
    padding: 20,
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#E5E7EB',
    marginBottom: 20,
  },
  techGrid: {
    gap: 20,
  },
  techCard: {
    backgroundColor: '#16213e',
    padding: 20,
    borderRadius: 12,
    marginBottom: 20,
  },
  techTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#E5E7EB',
    marginTop: 12,
    marginBottom: 16,
  },
  skillsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  skillBadge: {
    backgroundColor: 'rgba(139, 92, 246, 0.1)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(139, 92, 246, 0.2)',
  },
  skillText: {
    color: '#8B5CF6',
    fontSize: 14,
    fontWeight: '500',
  },
  projectsSection: {
    padding: 20,
  },
  projectCard: {
    backgroundColor: '#16213e',
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 20,
  },
  projectImage: {
    width: '100%',
    height: 200,
  },
  projectContent: {
    padding: 16,
  },
  projectTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#E5E7EB',
    marginBottom: 8,
  },
  projectDescription: {
    fontSize: 14,
    color: '#9CA3AF',
    lineHeight: 20,
    marginBottom: 16,
  },
  projectDuration: {
    backgroundColor: 'rgba(139, 92, 246, 0.1)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    alignSelf: 'flex-start',
  },
  durationText: {
    color: '#8B5CF6',
    fontSize: 14,
    fontWeight: '500',
  },
});