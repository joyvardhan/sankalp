import { StyleSheet, View, ScrollView, Text, Image, Pressable } from 'react-native';
import Animated, { 
  FadeInDown,
  useAnimatedStyle,
  withSpring,
  useSharedValue
} from 'react-native-reanimated';
import { Glasses, Smartphone, Gamepad, Cuboid as Cube } from 'lucide-react-native';

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

const technologies = [
  {
    icon: <Glasses size={24} color="#8B5CF6" />,
    title: "Virtual Reality",
    platforms: ["Oculus Quest", "HTC Vive", "Unity VR", "WebXR"]
  },
  {
    icon: <Smartphone size={24} color="#8B5CF6" />,
    title: "Augmented Reality",
    platforms: ["ARKit", "ARCore", "Vuforia", "8th Wall"]
  },
  {
    icon: <Gamepad size={24} color="#8B5CF6" />,
    title: "Interactive Design",
    platforms: ["3D Modeling", "Animation", "UI/UX", "Sound Design"]
  },
  {
    icon: <Cube size={24} color="#8B5CF6" />,
    title: "Development",
    platforms: ["Unity", "Unreal Engine", "Three.js", "A-Frame"]
  }
];

const projects = [
  {
    title: "Virtual Training Simulator",
    description: "Industrial safety training in VR environment",
    image: "https://images.unsplash.com/photo-1622979135225-d2ba269cf1ac?auto=format&fit=crop&w=600&q=80",
    duration: "12 weeks"
  },
  {
    title: "AR Product Visualization",
    description: "Mobile AR app for product showcase",
    image: "https://images.unsplash.com/photo-1633209942287-701d44019290?auto=format&fit=crop&w=600&q=80",
    duration: "8 weeks"
  },
  {
    title: "Interactive VR Experience",
    description: "Immersive storytelling and gaming",
    image: "https://images.unsplash.com/photo-1626387346567-68d0c05f3b54?auto=format&fit=crop&w=600&q=80",
    duration: "16 weeks"
  }
];

export default function ARVRScreen() {
  const scale = useSharedValue(1);

  const cardStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const onPressIn = () => {
    scale.value = withSpring(0.98);
  };

  const onPressOut = () => {
    scale.value = withSpring(1);
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Image
          source={{ uri: "https://images.unsplash.com/photo-1617802690992-15d93263d3a9?auto=format&fit=crop&w=1200&q=80" }}
          style={styles.headerImage}
        />
        <View style={styles.overlay} />
        <View style={styles.headerContent}>
          <Animated.Text 
            entering={FadeInDown.duration(1000)}
            style={styles.title}
          >
            AR/VR Development
          </Animated.Text>
          <Animated.Text 
            entering={FadeInDown.duration(1000).delay(200)}
            style={styles.subtitle}
          >
            Create immersive experiences with cutting-edge technology
          </Animated.Text>
        </View>
      </View>

      <View style={styles.technologiesSection}>
        <Animated.Text 
          entering={FadeInDown.duration(1000).delay(400)}
          style={styles.sectionTitle}
        >
          Technologies & Platforms
        </Animated.Text>

        <View style={styles.techGrid}>
          {technologies.map((tech, index) => (
            <Animated.View
              key={tech.title}
              entering={FadeInDown.duration(1000).delay(600 + index * 200)}
              style={styles.techCard}
            >
              {tech.icon}
              <Text style={styles.techTitle}>{tech.title}</Text>
              <View style={styles.platformsContainer}>
                {tech.platforms.map((platform) => (
                  <View key={platform} style={styles.platformBadge}>
                    <Text style={styles.platformText}>{platform}</Text>
                  </View>
                ))}
              </View>
            </Animated.View>
          ))}
        </View>
      </View>

      <View style={styles.projectsSection}>
        <Animated.Text 
          entering={FadeInDown.duration(1000).delay(1400)}
          style={styles.sectionTitle}
        >
          Featured Projects
        </Animated.Text>

        {projects.map((project, index) => (
          <AnimatedPressable
            key={project.title}
            entering={FadeInDown.duration(1000).delay(1600 + index * 200)}
            style={[styles.projectCard, cardStyle]}
            onPressIn={onPressIn}
            onPressOut={onPressOut}
          >
            <Image source={{ uri: project.image }} style={styles.projectImage} />
            <View style={styles.projectContent}>
              <Text style={styles.projectTitle}>{project.title}</Text>
              <Text style={styles.projectDescription}>{project.description}</Text>
              <View style={styles.projectDuration}>
                <Text style={styles.durationText}>{project.duration}</Text>
              </View>
            </View>
          </AnimatedPressable>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1a1a2e',
  },
  header: {
    height: 400,
    position: 'relative',
  },
  headerImage: {
    width: '100%',
    height: '100%',
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(26, 26, 46, 0.8)',
  },
  headerContent: {
    position: 'absolute',
    bottom: 40,
    left: 20,
    right: 20,
  },
  title: {
    fontSize: 36,
    fontWeight: 'bold',
    color: '#E5E7EB',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: '#9CA3AF',
    lineHeight: 24,
  },
  technologiesSection: {
    padding: 20,
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#E5E7EB',
    marginBottom: 20,
  },
  techGrid: {
    gap: 20,
  },
  techCard: {
    backgroundColor: '#16213e',
    padding: 20,
    borderRadius: 12,
    marginBottom: 20,
  },
  techTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#E5E7EB',
    marginTop: 12,
    marginBottom: 16,
  },
  platformsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  platformBadge: {
    backgroundColor: 'rgba(139, 92, 246, 0.1)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(139, 92, 246, 0.2)',
  },
  platformText: {
    color: '#8B5CF6',
    fontSize: 14,
    fontWeight: '500',
  },
  projectsSection: {
    padding: 20,
  },
  projectCard: {
    backgroundColor: '#16213e',
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 20,
  },
  projectImage: {
    width: '100%',
    height: 200,
  },
  projectContent: {
    padding: 16,
  },
  projectTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#E5E7EB',
    marginBottom: 8,
  },
  projectDescription: {
    fontSize: 14,
    color: '#9CA3AF',
    lineHeight: 20,
    marginBottom: 16,
  },
  projectDuration: {
    backgroundColor: 'rgba(139, 92, 246, 0.1)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    alignSelf: 'flex-start',
  },
  durationText: {
    color: '#8B5CF6',
    fontSize: 14,
    fontWeight: '500',
  },
});