import { StyleSheet, View, ScrollView, Text, Image, Pressable } from 'react-native';
import { Link } from 'expo-router';
import Animated, { 
  FadeInDown,
  useAnimatedStyle,
  withSpring,
  useSharedValue
} from 'react-native-reanimated';
import { ArrowRight, Briefcase, GraduationCap, Users } from 'lucide-react-native';

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

const features = [
  {
    icon: <Briefcase size={24} color="#8B5CF6" />,
    title: "100% Placement Assistance",
    description: "Guaranteed placement support with top tech companies"
  },
  {
    icon: <GraduationCap size={24} color="#8B5CF6" />,
    title: "Industry-Ready Training",
    description: "Curriculum designed by industry experts"
  },
  {
    icon: <Users size={24} color="#8B5CF6" />,
    title: "1:1 Mentorship",
    description: "Personal guidance from experienced professionals"
  }
];

const courses = [
  {
    title: "Full Stack Development",
    duration: "24 weeks",
    price: "₹49,999",
    image: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=600&q=80"
  },
  {
    title: "AI/ML Specialization",
    duration: "20 weeks",
    price: "₹59,999",
    image: "https://images.unsplash.com/photo-1555255707-c07966088b7b?auto=format&fit=crop&w=600&q=80"
  },
  {
    title: "AR/VR Development",
    duration: "16 weeks",
    price: "₹44,999",
    image: "https://images.unsplash.com/photo-1592478811341-4d9c69339600?auto=format&fit=crop&w=600&q=80"
  }
];

export default function CareersScreen() {
  const scale = useSharedValue(1);

  const cardStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const onPressIn = () => {
    scale.value = withSpring(0.98);
  };

  const onPressOut = () => {
    scale.value = withSpring(1);
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Image
          source={{ uri: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=1200&q=80" }}
          style={styles.headerImage}
        />
        <View style={styles.overlay} />
        <View style={styles.headerContent}>
          <Animated.Text 
            entering={FadeInDown.duration(1000)}
            style={styles.title}
          >
            Launch Your Tech Career
          </Animated.Text>
          <Animated.Text 
            entering={FadeInDown.duration(1000).delay(200)}
            style={styles.subtitle}
          >
            Transform your future with industry-leading training and placement support
          </Animated.Text>
        </View>
      </View>

      <View style={styles.featuresContainer}>
        {features.map((feature, index) => (
          <Animated.View
            key={feature.title}
            entering={FadeInDown.duration(1000).delay(400 + index * 200)}
            style={styles.featureCard}
          >
            {feature.icon}
            <Text style={styles.featureTitle}>{feature.title}</Text>
            <Text style={styles.featureDescription}>{feature.description}</Text>
          </Animated.View>
        ))}
      </View>

      <View style={styles.coursesSection}>
        <Animated.Text 
          entering={FadeInDown.duration(1000).delay(1000)}
          style={styles.sectionTitle}
        >
          Featured Courses
        </Animated.Text>

        {courses.map((course, index) => (
          <Link href="/careers/details" key={course.title} asChild>
            <AnimatedPressable
              entering={FadeInDown.duration(1000).delay(1200 + index * 200)}
              style={[styles.courseCard, cardStyle]}
              onPressIn={onPressIn}
              onPressOut={onPressOut}
            >
              <Image source={{ uri: course.image }} style={styles.courseImage} />
              <View style={styles.courseContent}>
                <Text style={styles.courseTitle}>{course.title}</Text>
                <View style={styles.courseDetails}>
                  <Text style={styles.courseDuration}>{course.duration}</Text>
                  <Text style={styles.coursePrice}>{course.price}</Text>
                </View>
                <View style={styles.courseAction}>
                  <Text style={styles.actionText}>Learn More</Text>
                  <ArrowRight size={20} color="#8B5CF6" />
                </View>
              </View>
            </AnimatedPressable>
          </Link>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1a1a2e',
  },
  header: {
    height: 400,
    position: 'relative',
  },
  headerImage: {
    width: '100%',
    height: '100%',
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(26, 26, 46, 0.8)',
  },
  headerContent: {
    position: 'absolute',
    bottom: 40,
    left: 20,
    right: 20,
  },
  title: {
    fontSize: 36,
    fontWeight: 'bold',
    color: '#E5E7EB',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: '#9CA3AF',
    lineHeight: 24,
  },
  featuresContainer: {
    padding: 20,
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 20,
    justifyContent: 'space-between',
  },
  featureCard: {
    backgroundColor: '#16213e',
    padding: 20,
    borderRadius: 12,
    width: '48%',
    alignItems: 'center',
    gap: 12,
  },
  featureTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#E5E7EB',
    textAlign: 'center',
  },
  featureDescription: {
    fontSize: 14,
    color: '#9CA3AF',
    textAlign: 'center',
    lineHeight: 20,
  },
  coursesSection: {
    padding: 20,
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#E5E7EB',
    marginBottom: 20,
  },
  courseCard: {
    backgroundColor: '#16213e',
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 20,
  },
  courseImage: {
    width: '100%',
    height: 200,
  },
  courseContent: {
    padding: 16,
  },
  courseTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#E5E7EB',
    marginBottom: 8,
  },
  courseDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  courseDuration: {
    fontSize: 14,
    color: '#9CA3AF',
  },
  coursePrice: {
    fontSize: 14,
    color: '#8B5CF6',
    fontWeight: '600',
  },
  courseAction: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  actionText: {
    fontSize: 14,
    color: '#8B5CF6',
    fontWeight: '600',
  },
});