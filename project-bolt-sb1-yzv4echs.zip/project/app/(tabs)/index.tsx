import { useEffect, useState } from 'react';
import { StyleSheet, View, Dimensions } from 'react-native';
import { Video, ResizeMode } from 'expo-av';
import { useTheme } from '@/context/ThemeContext';
import Animated, { 
  FadeIn,
  FadeInDown,
} from 'react-native-reanimated';

export default function HomeScreen() {
  const { colors } = useTheme();
  const [status, setStatus] = useState({});

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <Animated.View 
        entering={FadeIn.duration(1000)}
        style={styles.videoContainer}
      >
        <Video
          style={styles.video}
          source={{ uri: 'YOUR_VIDEO_URL_HERE' }}
          useNativeControls={false}
          resizeMode={ResizeMode.COVER}
          isLooping
          shouldPlay
          onPlaybackStatusUpdate={setStatus}
        />
        <View style={[styles.overlay, { backgroundColor: `${colors.background}80` }]} />
      </Animated.View>

      <Animated.Text 
        entering={FadeInDown.duration(1000).delay(500)}
        style={[styles.title, { color: colors.text }]}
      >
        SpectoV
      </Animated.Text>
      
      <Animated.Text 
        entering={FadeInDown.duration(1000).delay(1000)}
        style={[styles.subtitle, { color: colors.text }]}
      >
        Empowering Coders, Enabling Futures
      </Animated.Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  videoContainer: {
    ...StyleSheet.absoluteFillObject,
  },
  video: {
    flex: 1,
    width: Dimensions.get('window').width,
    height: Dimensions.get('window').height,
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
  },
  title: {
    fontSize: 48,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 18,
    textAlign: 'center',
    maxWidth: '80%',
  },
});