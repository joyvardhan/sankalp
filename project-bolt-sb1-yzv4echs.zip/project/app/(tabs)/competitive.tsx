import { StyleSheet, View, ScrollView, Text, Image, Pressable } from 'react-native';
import Animated, { 
  FadeInDown,
  useAnimatedStyle,
  withSpring,
  useSharedValue
} from 'react-native-reanimated';
import { Brain, Code2, Target, Trophy } from 'lucide-react-native';

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

const topics = [
  {
    icon: <Code2 size={24} color="#8B5CF6" />,
    title: "Data Structures",
    concepts: ["Arrays", "Linked Lists", "Trees", "Graphs"]
  },
  {
    icon: <Brain size={24} color="#8B5CF6" />,
    title: "Algorithms",
    concepts: ["Sorting", "Searching", "Dynamic Programming", "Greedy"]
  },
  {
    icon: <Target size={24} color="#8B5CF6" />,
    title: "Problem Solving",
    concepts: ["Pattern Recognition", "Optimization", "Time Complexity", "Space Analysis"]
  },
  {
    icon: <Trophy size={24} color="#8B5CF6" />,
    title: "Interview Prep",
    concepts: ["Mock Interviews", "Company Questions", "System Design", "Best Practices"]
  }
];

const challenges = [
  {
    title: "Array Manipulation",
    difficulty: "Medium",
    points: 50,
    submissions: 1234,
    success_rate: "76%"
  },
  {
    title: "Binary Tree Traversal",
    difficulty: "Hard",
    points: 100,
    submissions: 987,
    success_rate: "45%"
  },
  {
    title: "Dynamic Programming",
    difficulty: "Expert",
    points: 150,
    submissions: 567,
    success_rate: "32%"
  }
];

export default function CompetitiveScreen() {
  const scale = useSharedValue(1);

  const cardStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const onPressIn = () => {
    scale.value = withSpring(0.98);
  };

  const onPressOut = () => {
    scale.value = withSpring(1);
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Image
          source={{ uri: "https://images.unsplash.com/photo-1516116216624-53e697fedbea?auto=format&fit=crop&w=1200&q=80" }}
          style={styles.headerImage}
        />
        <View style={styles.overlay} />
        <View style={styles.headerContent}>
          <Animated.Text 
            entering={FadeInDown.duration(1000)}
            style={styles.title}
          >
            Competitive Programming
          </Animated.Text>
          <Animated.Text 
            entering={FadeInDown.duration(1000).delay(200)}
            style={styles.subtitle}
          >
            Master algorithms and ace technical interviews
          </Animated.Text>
        </View>
      </View>

      <View style={styles.topicsSection}>
        <Animated.Text 
          entering={FadeInDown.duration(1000).delay(400)}
          style={styles.sectionTitle}
        >
          Core Topics
        </Animated.Text>

        <View style={styles.topicsGrid}>
          {topics.map((topic, index) => (
            <Animated.View
              key={topic.title}
              entering={FadeInDown.duration(1000).delay(600 + index * 200)}
              style={styles.topicCard}
            >
              {topic.icon}
              <Text style={styles.topicTitle}>{topic.title}</Text>
              <View style={styles.conceptsContainer}>
                {topic.concepts.map((concept) => (
                  <View key={concept} style={styles.conceptBadge}>
                    <Text style={styles.conceptText}>{concept}</Text>
                  </View>
                ))}
              </View>
            </Animated.View>
          ))}
        </View>
      </View>

      <View style={styles.challengesSection}>
        <Animated.Text 
          entering={FadeInDown.duration(1000).delay(1400)}
          style={styles.sectionTitle}
        >
          Daily Challenges
        </Animated.Text>

        {challenges.map((challenge, index) => (
          <AnimatedPressable
            key={challenge.title}
            entering={FadeInDown.duration(1000).delay(1600 + index * 200)}
            style={[styles.challengeCard, cardStyle]}
            onPressIn={onPressIn}
            onPressOut={onPressOut}
          >
            <View style={styles.challengeHeader}>
              <Text style={styles.challengeTitle}>{challenge.title}</Text>
              <View style={[styles.difficultyBadge, styles[`difficulty_${challenge.difficulty.toLowerCase()}`]]}>
                <Text style={styles.difficultyText}>{challenge.difficulty}</Text>
              </View>
            </View>
            <View style={styles.challengeStats}>
              <View style={styles.statItem}>
                <Text style={styles.statLabel}>Points</Text>
                <Text style={styles.statValue}>{challenge.points}</Text>
              </View>
              <View style={styles.statItem}>
                <Text style={styles.statLabel}>Submissions</Text>
                <Text style={styles.statValue}>{challenge.submissions}</Text>
              </View>
              <View style={styles.statItem}>
                <Text style={styles.statLabel}>Success Rate</Text>
                <Text style={styles.statValue}>{challenge.success_rate}</Text>
              </View>
            </View>
          </AnimatedPressable>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1a1a2e',
  },
  header: {
    height: 400,
    position: 'relative',
  },
  headerImage: {
    width: '100%',
    height: '100%',
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(26, 26, 46, 0.8)',
  },
  headerContent: {
    position: 'absolute',
    bottom: 40,
    left: 20,
    right: 20,
  },
  title: {
    fontSize: 36,
    fontWeight: 'bold',
    color: '#E5E7EB',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: '#9CA3AF',
    lineHeight: 24,
  },
  topicsSection: {
    padding: 20,
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#E5E7EB',
    marginBottom: 20,
  },
  topicsGrid: {
    gap: 20,
  },
  topicCard: {
    backgroundColor: '#16213e',
    padding: 20,
    borderRadius: 12,
    marginBottom: 20,
  },
  topicTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#E5E7EB',
    marginTop: 12,
    marginBottom: 16,
  },
  conceptsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  conceptBadge: {
    backgroundColor: 'rgba(139, 92, 246, 0.1)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(139, 92, 246, 0.2)',
  },
  conceptText: {
    color: '#8B5CF6',
    fontSize: 14,
    fontWeight: '500',
  },
  challengesSection: {
    padding: 20,
  },
  challengeCard: {
    backgroundColor: '#16213e',
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  challengeHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  challengeTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#E5E7EB',
    flex: 1,
  },
  difficultyBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  difficulty_medium: {
    backgroundColor: 'rgba(245, 158, 11, 0.1)',
  },
  difficulty_hard: {
    backgroundColor: 'rgba(239, 68, 68, 0.1)',
  },
  difficulty_expert: {
    backgroundColor: 'rgba(139, 92, 246, 0.1)',
  },
  difficultyText: {
    fontSize: 14,
    fontWeight: '500',
  },
  challengeStats: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  statItem: {
    alignItems: 'center',
  },
  statLabel: {
    fontSize: 14,
    color: '#9CA3AF',
    marginBottom: 4,
  },
  statValue: {
    fontSize: 16,
    fontWeight: '600',
    color: '#E5E7EB',
  },
});