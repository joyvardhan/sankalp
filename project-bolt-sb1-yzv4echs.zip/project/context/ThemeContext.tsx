import React, { createContext, useContext } from 'react';

const theme = {
  colors: {
    primary: '#8B5CF6',
    background: '#1a1a2e',
    surface: '#16213e',
    text: '#E5E7EB',
    border: '#374151',
    accent: '#7c3aed',
  },
};

const ThemeContext = createContext(theme);

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  return (
    <ThemeContext.Provider value={theme}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  return useContext(ThemeContext);
}